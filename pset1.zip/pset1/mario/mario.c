#include <stdio.h>
#include <cs50.h>

int main(void)
{
    //declaration of all ints and functions used early
    int height;
    int spaces;
    int hashes;
    void print_spaces();
    void print_hashes();

    //do/while loop checks input is valid using ||
    do
    {
        height = get_int("Height: ");
        spaces = height - 1;
        hashes = height - spaces;
    }
    while (height < 1 || height > 8);
    {
        //for loop carries out functions defined below in order required to draw pyramids
        for (int h = 0; h < height; h++)
        {

            print_spaces(spaces);
            print_hashes(hashes);
            printf("  ");
            print_hashes(hashes);
            printf("\n");
            spaces--;
            hashes++;

        }
    }
}

//below are the functions used in the main loop
void print_spaces(spaces)
{
    for (int i = 0; i < spaces; i++)
    {
        printf(" ");
    }
}
void print_hashes(hashes)
{
    for (int j = 0; j < hashes; j++)
    {
        printf("#");
    }
}