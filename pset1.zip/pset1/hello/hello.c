#include <stdio.h>
#include <cs50.h>


//Prompt user for name and return using printf
int main(void)
{
    string name = get_string("what is your name?\n");
    printf("hello, %s\n", name);
}