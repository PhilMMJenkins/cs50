#include <stdio.h>
#include <cs50.h>
#include <math.h>

int main(void)
{
    //declare the long for credit card number, a modulo variable and the checksum running total
    long cc = get_long("Number: ");
    long m = 10;
    int cs = 0;

    //the following adds up digits for the check sum
    for (int i = 0; i < 8; i++)
    {
        //for odd numbered digits:
        int x = (cc % m) / (m / 10);
        cs += x;
        m *= 10;
        
        //for even numbered digits:
        x = (cc % m) / (m / 10);
        x *= 2;
        if (x >= 10)
        {
            int y = x / 10;
            int z = x % 10;
            cs += (y + z);
        }
        else
        {
            cs += x;
        }
        m *= 10;
    }
    //checksum variable remainder created 
    cs %= 10;

    //once the check sum is passed, a series of if statements can determine card type
    if (cs == 0)
    {
        if ((cc >= (34 * pow(10, 13)) && (cc < 35 * pow(10, 13))) || (cc >= (37 * pow(10, 13)) && (cc < 38 * pow(10, 13))))
        {
            printf("AMEX\n");
        }
        else if (cc >= (51 * pow(10, 14)) && (cc < 56 * pow(10, 14)))
        {
            printf("MASTERCARD\n");
        }
        else if (cc >= (4 * pow(10, 15)) && (cc < 5 * pow(10, 15)))
        {
            printf("VISA\n");
        }
        else
        {
            printf("INVALID\n");
        }
    }
    else
    {
        printf("INVALID\n");
    }
}
